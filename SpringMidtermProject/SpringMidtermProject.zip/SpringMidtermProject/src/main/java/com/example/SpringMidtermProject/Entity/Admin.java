package com.example.SpringMidtermProject.Entity;

public class Admin {
}
