package com.example.SpringMidtermProject.Controllers;

public class AdminController {
}
