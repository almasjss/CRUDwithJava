package com.example.SpringMidtermProject.Service;

public class AdminService {
}
