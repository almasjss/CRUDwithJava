package com.example.SpringMidtermProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMidtermProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMidtermProjectApplication.class, args);
	}

}
