package com.example.SpringMidtermProject.Models;

public class AdminRequest {
}
