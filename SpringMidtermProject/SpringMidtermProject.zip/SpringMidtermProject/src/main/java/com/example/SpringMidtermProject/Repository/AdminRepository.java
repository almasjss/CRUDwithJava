package com.example.SpringMidtermProject.Repository;

public interface AdminRepository {
}
